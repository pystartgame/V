//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CmQkeUCf.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/api/chat"],
		preloads: ["/assets/index-LPvKHBVl.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-LPvKHBVl.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BuuIml6T.js"]
	}
} });
//#endregion
export { tsrStartManifest };
