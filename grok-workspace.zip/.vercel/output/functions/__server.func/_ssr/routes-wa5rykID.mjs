import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Square, c as RefreshCw, d as PanelLeft, f as Moon, h as ArrowUp, i as Sun, l as Plus, m as Check, o as SquarePen, p as Copy, r as Trash2, s as Search, t as X, u as Pencil } from "../_libs/lucide-react.mjs";
import { n as previewPathPrefix } from "./router-CrG9Zc3X.mjs";
import { n as isToday, t as isYesterday } from "../_libs/date-fns.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-wa5rykID.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var MAX_CONVERSATIONS = 40;
var TITLE_FALLBACK = "Новый диалог";
function uid() {
	return crypto.randomUUID();
}
function titleFrom(text) {
	const line = text.trim().split("\n")[0]?.replace(/\s+/g, " ") ?? "";
	if (!line) return TITLE_FALLBACK;
	return line.length > 42 ? `${line.slice(0, 42).trimEnd()}…` : line;
}
function historyFrom(messages) {
	return messages.filter((message) => message.content.trim() && message.role).filter((message) => message.role === "user" || message.status === "done").slice(-12).map((message) => ({
		role: message.role,
		content: message.content.trim().slice(0, 4e3)
	}));
}
function touch(conversations) {
	return [...conversations].sort((a, b) => b.updatedAt - a.updatedAt).slice(0, MAX_CONVERSATIONS);
}
var useChatStore = create()(persist((set, get) => ({
	conversations: [],
	activeId: null,
	theme: "light",
	setTheme: (theme) => set({ theme }),
	select: (id) => set({ activeId: id }),
	remove: (id) => set((state) => {
		const conversations = state.conversations.filter((item) => item.id !== id);
		const nextActive = conversations.slice().sort((a, b) => b.updatedAt - a.updatedAt)[0]?.id;
		return {
			conversations,
			activeId: state.activeId === id ? nextActive ?? null : state.activeId
		};
	}),
	rename: (id, title) => set((state) => ({ conversations: state.conversations.map((item) => item.id === id ? {
		...item,
		title: title.trim() || TITLE_FALLBACK,
		updatedAt: Date.now()
	} : item) })),
	commitUser: (activeId, text) => {
		const now = Date.now();
		const user = {
			id: uid(),
			role: "user",
			content: text.trim(),
			createdAt: now,
			status: "done"
		};
		const assistant = {
			id: uid(),
			role: "assistant",
			content: "",
			createdAt: now,
			status: "streaming"
		};
		const existing = get().conversations.find((item) => item.id === activeId);
		if (!existing) {
			const conv = {
				id: uid(),
				title: titleFrom(text),
				createdAt: now,
				updatedAt: now,
				messages: [user, assistant]
			};
			set((state) => ({
				activeId: conv.id,
				conversations: touch([conv, ...state.conversations])
			}));
			return {
				convId: conv.id,
				assistantId: assistant.id,
				history: historyFrom([user])
			};
		}
		const messages = [
			...existing.messages,
			user,
			assistant
		];
		const title = existing.messages.some((message) => message.role === "user") || existing.title !== TITLE_FALLBACK ? existing.title : titleFrom(text);
		const next = {
			...existing,
			title,
			messages,
			updatedAt: now
		};
		set((state) => ({
			activeId: existing.id,
			conversations: touch(state.conversations.map((item) => item.id === existing.id ? next : item))
		}));
		return {
			convId: existing.id,
			assistantId: assistant.id,
			history: historyFrom(messages.slice(0, -1))
		};
	},
	rewindUser: (convId, messageId, text) => {
		const conv = get().conversations.find((item) => item.id === convId);
		if (!conv) return null;
		const index = conv.messages.findIndex((message) => message.id === messageId);
		if (index < 0 || conv.messages[index]?.role !== "user") return null;
		const now = Date.now();
		const user = {
			...conv.messages[index],
			content: text.trim(),
			status: "done"
		};
		const assistant = {
			id: uid(),
			role: "assistant",
			content: "",
			createdAt: now,
			status: "streaming"
		};
		const messages = [
			...conv.messages.slice(0, index),
			user,
			assistant
		];
		set((state) => ({ conversations: state.conversations.map((item) => item.id === convId ? {
			...item,
			title: index === 0 ? titleFrom(text) : item.title,
			messages,
			updatedAt: now
		} : item) }));
		return {
			assistantId: assistant.id,
			history: historyFrom(messages.slice(0, -1))
		};
	},
	regenerate: (convId) => {
		const conv = get().conversations.find((item) => item.id === convId);
		if (!conv) return null;
		const last = conv.messages[conv.messages.length - 1];
		if (!last || last.role !== "assistant") return null;
		const now = Date.now();
		const assistant = {
			...last,
			content: "",
			error: void 0,
			status: "streaming",
			createdAt: now
		};
		const messages = [...conv.messages.slice(0, -1), assistant];
		set((state) => ({ conversations: state.conversations.map((item) => item.id === convId ? {
			...item,
			messages,
			updatedAt: now
		} : item) }));
		return {
			assistantId: assistant.id,
			history: historyFrom(messages.slice(0, -1))
		};
	},
	appendDelta: (convId, messageId, delta) => set((state) => ({ conversations: state.conversations.map((item) => item.id !== convId ? item : {
		...item,
		messages: item.messages.map((message) => message.id === messageId && message.status === "streaming" ? {
			...message,
			content: message.content + delta
		} : message)
	}) })),
	finish: (convId, messageId, status, error) => set((state) => ({ conversations: state.conversations.map((item) => item.id !== convId ? item : {
		...item,
		updatedAt: Date.now(),
		messages: item.messages.map((message) => message.id === messageId ? {
			...message,
			status,
			error
		} : message)
	}) }))
}), {
	name: "sable-chat-v1",
	skipHydration: true,
	partialize: (state) => ({
		conversations: state.conversations,
		activeId: state.activeId,
		theme: state.theme
	}),
	onRehydrateStorage: () => (state) => {
		if (!state) return;
		useChatStore.setState({ conversations: state.conversations.map((conversation) => ({
			...conversation,
			messages: conversation.messages.map((message) => message.status === "streaming" ? {
				...message,
				status: "stopped"
			} : message)
		})) });
	}
}));
function parseInlines(src) {
	const out = [];
	let buf = "";
	let i = 0;
	const flush = () => {
		if (!buf) return;
		out.push({
			type: "text",
			text: buf
		});
		buf = "";
	};
	while (i < src.length) {
		if (src[i] === "`") {
			const end = src.indexOf("`", i + 1);
			if (end > i + 1) {
				flush();
				out.push({
					type: "code",
					text: src.slice(i + 1, end)
				});
				i = end + 1;
				continue;
			}
		}
		if (src.startsWith("**", i) || src.startsWith("__", i)) {
			const mark = src.slice(i, i + 2);
			const end = src.indexOf(mark, i + 2);
			if (end > i + 2) {
				flush();
				out.push({
					type: "strong",
					text: src.slice(i + 2, end)
				});
				i = end + 2;
				continue;
			}
		}
		if ((src[i] === "*" || src[i] === "_") && src[i + 1] !== src[i]) {
			const mark = src[i];
			const end = src.indexOf(mark, i + 1);
			if (end > i + 1) {
				flush();
				out.push({
					type: "em",
					text: src.slice(i + 1, end)
				});
				i = end + 1;
				continue;
			}
		}
		if (src[i] === "[") {
			const close = src.indexOf("]", i + 1);
			if (close > i + 1 && src[close + 1] === "(") {
				const end = src.indexOf(")", close + 2);
				if (end > close + 2) {
					const href = src.slice(close + 2, end).trim();
					if (/^https?:\/\//i.test(href)) {
						flush();
						out.push({
							type: "link",
							text: src.slice(i + 1, close),
							href
						});
						i = end + 1;
						continue;
					}
				}
			}
		}
		buf += src[i];
		i += 1;
	}
	flush();
	return out;
}
function isFence(line) {
	return line.trimStart().startsWith("```");
}
function parseBlocks(src) {
	const lines = src.replace(/\r\n/g, "\n").split("\n");
	const blocks = [];
	let i = 0;
	while (i < lines.length) {
		const line = lines[i] ?? "";
		if (isFence(line)) {
			const lang = line.trim().slice(3).trim();
			const code = [];
			i += 1;
			while (i < lines.length && !isFence(lines[i] ?? "")) {
				code.push(lines[i] ?? "");
				i += 1;
			}
			if (i < lines.length) i += 1;
			blocks.push({
				type: "code",
				lang,
				code: code.join("\n")
			});
			continue;
		}
		const heading = /^(#{1,3})\s+(.+)$/.exec(line);
		if (heading) {
			blocks.push({
				type: "h",
				level: heading[1].length,
				inlines: parseInlines(heading[2])
			});
			i += 1;
			continue;
		}
		if (/^(-{3,}|\*{3,})$/.test(line.trim())) {
			blocks.push({ type: "hr" });
			i += 1;
			continue;
		}
		if (/^\s*>\s?/.test(line)) {
			const parts = [];
			while (i < lines.length && /^\s*>\s?/.test(lines[i] ?? "")) {
				parts.push((lines[i] ?? "").replace(/^\s*>\s?/, ""));
				i += 1;
			}
			blocks.push({
				type: "quote",
				inlines: parseInlines(parts.join(" "))
			});
			continue;
		}
		if (/^\s*[-*]\s+/.test(line)) {
			const items = [];
			while (i < lines.length && /^\s*[-*]\s+/.test(lines[i] ?? "")) {
				items.push(parseInlines((lines[i] ?? "").replace(/^\s*[-*]\s+/, "")));
				i += 1;
			}
			blocks.push({
				type: "ul",
				items
			});
			continue;
		}
		if (/^\s*\d+\.\s+/.test(line)) {
			const items = [];
			while (i < lines.length && /^\s*\d+\.\s+/.test(lines[i] ?? "")) {
				items.push(parseInlines((lines[i] ?? "").replace(/^\s*\d+\.\s+/, "")));
				i += 1;
			}
			blocks.push({
				type: "ol",
				items
			});
			continue;
		}
		if (line.trim() === "") {
			i += 1;
			continue;
		}
		const para = [];
		while (i < lines.length) {
			const current = lines[i] ?? "";
			if (current.trim() === "" || isFence(current) || /^(#{1,3})\s+/.test(current) || /^(-{3,}|\*{3,})$/.test(current.trim()) || /^\s*>\s?/.test(current) || /^\s*[-*]\s+/.test(current) || /^\s*\d+\.\s+/.test(current)) break;
			para.push(current.trim());
			i += 1;
		}
		if (para.length) blocks.push({
			type: "p",
			inlines: parseInlines(para.join(" "))
		});
	}
	return blocks;
}
function Inlines({ items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: items.map((item, index) => {
		if (item.type === "text") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.text }, index);
		if (item.type === "code") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: item.text }, index);
		if (item.type === "strong") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: item.text }, index);
		if (item.type === "em") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: item.text }, index);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: item.href,
			target: "_blank",
			rel: "noreferrer noopener",
			children: item.text
		}, index);
	}) });
}
function CodeBlock({ lang, code }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "code-block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: lang || "код" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "inline-flex min-h-10 items-center gap-1 rounded-control px-2 text-xs text-muted hover:bg-hover hover:text-fg",
			onClick: () => {
				navigator.clipboard.writeText(code).then(() => {
					setCopied(true);
					window.setTimeout(() => setCopied(false), 1400);
				});
			},
			children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" }), copied ? "Скопировано" : "Копировать"]
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: code }) })]
	});
}
function Markdown({ text, streaming = false }) {
	const blocks = parseBlocks(text);
	if (!blocks.length) return streaming ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "stream-caret",
		"aria-hidden": true
	}) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "prose-chat",
		children: blocks.map((block, index) => {
			const caret = streaming && index === blocks.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "stream-caret",
				"aria-hidden": true
			}) : null;
			if (block.type === "p") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inlines, { items: block.inlines }), caret] }, index);
			if (block.type === "h") {
				const Tag = `h${block.level}`;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tag, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inlines, { items: block.inlines }), caret] }, index);
			}
			if (block.type === "code") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, {
				lang: block.lang,
				code: block.code
			}), caret] }, index);
			if (block.type === "ul" || block.type === "ol") {
				const Tag = block.type === "ul" ? "ul" : "ol";
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { children: block.items.map((item, itemIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inlines, { items: item }) }, itemIndex)) }), caret] }, index);
			}
			if (block.type === "quote") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inlines, { items: block.inlines }), caret] }, index);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", {}, index);
		})
	});
}
/** Keep API calls on the same preview prefix the page was opened under. */
function apiUrl(path) {
	if (typeof window === "undefined") return path;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? `${prefix}${path}` : path;
}
async function streamReply(messages, signal, onDelta) {
	const response = await fetch(apiUrl("/api/chat"), {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({ messages }),
		signal
	});
	if (!response.ok) {
		let message = "Сейчас не получается ответить. Попробуйте ещё раз.";
		try {
			const body = await response.json();
			if (typeof body.error === "string" && body.error) message = body.error;
		} catch {}
		throw new Error(message);
	}
	if (!response.body) throw new Error("Сейчас не получается ответить. Попробуйте ещё раз.");
	const reader = response.body.getReader();
	const decoder = new TextDecoder();
	let buffer = "";
	const handle = (raw) => {
		const data = raw.split("\n").filter((line) => line.startsWith("data:")).map((line) => line.slice(5).trim()).join("");
		if (!data) return;
		let payload;
		try {
			payload = JSON.parse(data);
		} catch {
			throw new Error("Сейчас не получается ответить. Попробуйте ещё раз.");
		}
		if (payload.error) throw new Error(payload.error);
		if (payload.delta) onDelta(payload.delta);
	};
	const consume = (chunk, flush) => {
		buffer += chunk.replace(/\r\n/g, "\n");
		let splitAt = buffer.indexOf("\n\n");
		while (splitAt >= 0) {
			const raw = buffer.slice(0, splitAt);
			buffer = buffer.slice(splitAt + 2);
			handle(raw);
			splitAt = buffer.indexOf("\n\n");
		}
		if (flush && buffer.trim()) {
			handle(buffer);
			buffer = "";
		}
	};
	while (true) {
		const { done, value } = await reader.read();
		if (done) {
			consume(decoder.decode(), true);
			break;
		}
		consume(decoder.decode(value, { stream: true }), false);
	}
}
var SUGGESTIONS = [
	{
		title: "Объяснить просто",
		text: "Квантовая запутанность без формул",
		prompt: "Объясни квантовую запутанность простыми словами, без формул."
	},
	{
		title: "План на неделю",
		text: "TypeScript для тех, кто знает JavaScript",
		prompt: "Составь план на 7 дней, чтобы подтянуть TypeScript, если я уже пишу на JavaScript."
	},
	{
		title: "Вежливое письмо",
		text: "Отказ от встречи без выдуманных причин",
		prompt: "Помоги вежливо отказаться от встречи, не выдумывая причин и без лишней воды."
	},
	{
		title: "Ужин из обычного",
		text: "Пять идей из яиц, пасты и овощей",
		prompt: "Предложи 5 ужинов из продуктов, которые обычно есть дома: яйца, макароны, овощи, сыр."
	}
];
function groupLabel(ts) {
	if (isToday(ts)) return "Сегодня";
	if (isYesterday(ts)) return "Вчера";
	if (Date.now() - ts < 6048e5) return "На этой неделе";
	return "Ранее";
}
function IconButton({ label, className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		className: cn("inline-flex size-11 shrink-0 items-center justify-center rounded-control text-muted transition-colors duration-150 ease-out-smooth hover:bg-hover hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink disabled:pointer-events-none disabled:opacity-40", className),
		...props,
		children
	});
}
function CopyButton({ text }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
		label: copied ? "Скопировано" : "Копировать",
		onClick: () => {
			navigator.clipboard.writeText(text).then(() => {
				setCopied(true);
				window.setTimeout(() => setCopied(false), 1400);
			}, () => void 0);
		},
		children: copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" })
	});
}
function ChatApp() {
	const conversations = useChatStore((state) => state.conversations);
	const activeId = useChatStore((state) => state.activeId);
	const theme = useChatStore((state) => state.theme);
	const active = conversations.find((item) => item.id === activeId) ?? null;
	const [draft, setDraft] = (0, import_react.useState)("");
	const [sidebarOpen, setSidebarOpen] = (0, import_react.useState)(false);
	const [query, setQuery] = (0, import_react.useState)("");
	const [pendingId, setPendingId] = (0, import_react.useState)(null);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [rename, setRename] = (0, import_react.useState)(null);
	const [confirmId, setConfirmId] = (0, import_react.useState)(null);
	const abortRef = (0, import_react.useRef)(null);
	const inflight = (0, import_react.useRef)(false);
	const scrollerRef = (0, import_react.useRef)(null);
	const stickRef = (0, import_react.useRef)(true);
	const composerRef = (0, import_react.useRef)(null);
	const skipRenameBlur = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		useChatStore.persist.rehydrate();
	}, []);
	(0, import_react.useEffect)(() => {
		document.documentElement.dataset.theme = theme;
	}, [theme]);
	(0, import_react.useEffect)(() => {
		setEditing(null);
		stickRef.current = true;
	}, [activeId]);
	const tail = active?.messages[active.messages.length - 1];
	(0, import_react.useEffect)(() => {
		const el = scrollerRef.current;
		if (!el || !stickRef.current) return;
		el.scrollTop = el.scrollHeight;
	}, [
		active?.id,
		active?.messages.length,
		tail?.content,
		tail?.status
	]);
	(0, import_react.useEffect)(() => {
		if (!sidebarOpen) return;
		const onKey = (event) => {
			if (event.key === "Escape") setSidebarOpen(false);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [sidebarOpen]);
	const fitComposer = (node) => {
		if (!node) return;
		node.style.height = "0px";
		node.style.height = `${Math.min(node.scrollHeight, 192)}px`;
	};
	const run = async (convId, assistantId, history) => {
		abortRef.current?.abort();
		const ctrl = new AbortController();
		abortRef.current = ctrl;
		setPendingId(convId);
		try {
			await streamReply(history, ctrl.signal, (delta) => {
				useChatStore.getState().appendDelta(convId, assistantId, delta);
			});
			useChatStore.getState().finish(convId, assistantId, "done");
		} catch (error) {
			if (ctrl.signal.aborted) {
				useChatStore.getState().finish(convId, assistantId, "stopped");
				return;
			}
			const message = error instanceof Error && error.message ? error.message : "Сейчас не получается ответить. Попробуйте ещё раз.";
			useChatStore.getState().finish(convId, assistantId, "error", message);
		} finally {
			if (abortRef.current === ctrl) abortRef.current = null;
			inflight.current = false;
			setPendingId((current) => current === convId ? null : current);
		}
	};
	const sendText = (text) => {
		const trimmed = text.trim();
		if (!trimmed || inflight.current || trimmed.length > 4e3) return;
		inflight.current = true;
		const { convId, assistantId, history } = useChatStore.getState().commitUser(useChatStore.getState().activeId, trimmed);
		setDraft("");
		if (composerRef.current) composerRef.current.style.height = "0px";
		setSidebarOpen(false);
		run(convId, assistantId, history);
	};
	const startNew = () => {
		useChatStore.getState().select(null);
		setDraft("");
		setSidebarOpen(false);
		composerRef.current?.focus();
	};
	const busyHere = pendingId !== null && pendingId === active?.id;
	const busyElsewhere = pendingId !== null && pendingId !== active?.id;
	const tooLong = draft.trim().length > 4e3;
	const filtered = conversations.slice().sort((a, b) => b.updatedAt - a.updatedAt).filter((item) => {
		const q = query.trim().toLowerCase();
		if (!q) return true;
		return item.title.toLowerCase().includes(q) || item.messages.some((message) => message.content.toLowerCase().includes(q));
	});
	const groups = [];
	for (const item of filtered) {
		const label = groupLabel(item.updatedAt);
		const last = groups[groups.length - 1];
		if (!last || last.label !== label) groups.push({
			label,
			items: [item]
		});
		else last.items.push(item);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh overflow-hidden bg-paper text-fg",
		children: [
			sidebarOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "Закрыть список диалогов",
				className: "fixed inset-0 z-30 bg-ink/40 md:hidden",
				onClick: () => setSidebarOpen(false)
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: cn("sidebar-panel fixed inset-y-0 left-0 z-40 flex w-72 shrink-0 flex-col bg-sidebar text-sidebar-fg md:static", sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-4 pt-5 pb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-serif text-2xl leading-none tracking-tight",
							children: "Sable"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-sidebar-muted",
							children: "На модели Grok"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: startNew,
							className: "inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-control bg-sidebar-fg px-3 text-sm font-medium text-sidebar transition-opacity duration-150 hover:opacity-90 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sidebar-fg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Новый диалог"]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-3 pt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-sidebar-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: query,
								onChange: (event) => setQuery(event.target.value),
								placeholder: "Поиск по диалогам",
								"aria-label": "Поиск по диалогам",
								className: "h-11 w-full rounded-control border border-sidebar-line bg-transparent pr-3 pl-10 text-sm text-sidebar-fg placeholder:text-sidebar-muted focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sidebar-fg"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 min-h-0 flex-1 overflow-y-auto px-2 pb-3",
						children: groups.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-3 py-6 text-sm text-sidebar-muted",
							children: query.trim() ? "Ничего не нашлось" : "Диалогов пока нет"
						}) : groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "mb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "px-3 py-2 text-xs font-medium text-sidebar-muted",
								children: group.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: group.items.map((item) => {
								const selected = item.id === activeId;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "chat-row flex items-center rounded-control",
									children: [rename?.id === item.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										autoFocus: true,
										value: rename.text,
										"aria-label": "Название диалога",
										onChange: (event) => setRename({
											id: item.id,
											text: event.target.value
										}),
										onBlur: () => {
											if (skipRenameBlur.current) {
												skipRenameBlur.current = false;
												return;
											}
											useChatStore.getState().rename(item.id, rename.text);
											setRename(null);
										},
										onKeyDown: (event) => {
											if (event.key === "Enter") event.currentTarget.blur();
											if (event.key === "Escape") {
												skipRenameBlur.current = true;
												setRename(null);
											}
										},
										className: "mx-1 h-11 min-w-0 flex-1 rounded-control border border-sidebar-line bg-sidebar px-2 text-sm text-sidebar-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sidebar-fg"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-current": selected ? "page" : void 0,
										onClick: () => {
											useChatStore.getState().select(item.id);
											setSidebarOpen(false);
											setConfirmId(null);
										},
										className: cn("min-h-11 min-w-0 flex-1 truncate rounded-control px-3 text-left text-sm", selected ? "bg-sidebar-hover" : "hover:bg-sidebar-hover"),
										children: item.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "row-actions flex shrink-0",
										children: confirmId === item.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "inline-flex h-11 items-center px-2 text-xs font-medium text-danger",
											onClick: () => {
												useChatStore.getState().remove(item.id);
												setConfirmId(null);
											},
											children: "Удалить"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
											label: "Отмена",
											className: "text-sidebar-muted hover:bg-sidebar-hover hover:text-sidebar-fg",
											onClick: () => setConfirmId(null),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
										})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
											label: "Переименовать",
											className: "text-sidebar-muted hover:bg-sidebar-hover hover:text-sidebar-fg",
											onClick: () => setRename({
												id: item.id,
												text: item.title
											}),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
											label: "Удалить диалог",
											className: "text-sidebar-muted hover:bg-sidebar-hover hover:text-sidebar-fg",
											onClick: () => setConfirmId(item.id),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
										})] })
									})]
								}, item.id);
							}) })]
						}, group.label))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-t border-sidebar-line px-2 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => useChatStore.getState().setTheme(theme === "dark" ? "light" : "dark"),
							className: "inline-flex min-h-11 items-center gap-2 rounded-control px-3 text-sm text-sidebar-fg hover:bg-sidebar-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sidebar-fg",
							children: [theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-4" }), theme === "dark" ? "Светлая" : "Тёмная"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pr-3 text-xs text-sidebar-muted",
							children: "Grok 4.5"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "flex h-14 shrink-0 items-center gap-1 px-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
								label: "Открыть список диалогов",
								className: "md:hidden",
								onClick: () => setSidebarOpen(true),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelLeft, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "min-w-0 flex-1 truncate px-2 text-center text-sm font-medium",
								children: active?.title ?? "Sable"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
								label: "Новый диалог",
								className: "md:hidden",
								onClick: startNew,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquarePen, { className: "size-5" })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: scrollerRef,
						onScroll: (event) => {
							const el = event.currentTarget;
							stickRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
						},
						className: "min-h-0 flex-1 overflow-y-auto",
						children: active && active.messages.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto flex w-full max-w-3xl flex-col gap-6 px-4 py-4",
							children: active.messages.map((message, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageRow, {
								message,
								isLast: index === active.messages.length - 1,
								pending: busyHere,
								editing: editing?.id === message.id ? editing.text : null,
								onEditChange: (text) => setEditing({
									id: message.id,
									text
								}),
								onStartEdit: () => setEditing({
									id: message.id,
									text: message.content
								}),
								onCancelEdit: () => setEditing(null),
								onSubmitEdit: () => {
									if (!editing || inflight.current) return;
									const text = editing.text.trim();
									if (!text || text.length > 4e3) return;
									inflight.current = true;
									const result = useChatStore.getState().rewindUser(active.id, message.id, text);
									setEditing(null);
									if (!result) {
										inflight.current = false;
										return;
									}
									run(active.id, result.assistantId, result.history);
								},
								onRegenerate: () => {
									if (inflight.current) return;
									inflight.current = true;
									const result = useChatStore.getState().regenerate(active.id);
									if (!result) {
										inflight.current = false;
										return;
									}
									run(active.id, result.assistantId, result.history);
								}
							}, message.id))
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto flex min-h-full w-full max-w-2xl flex-col justify-center px-4 py-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "display-title text-center",
									children: "С чего начнём?"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mx-auto mt-3 max-w-md text-center text-sm text-muted",
									children: "Спросите, попросите черновик или разберите задачу. Диалоги остаются в этом браузере."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-8 grid grid-cols-1 gap-2 sm:grid-cols-2",
									children: SUGGESTIONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										disabled: pendingId !== null,
										onClick: () => sendText(item.prompt),
										className: "min-h-11 rounded-panel border border-line bg-canvas px-4 py-3 text-left transition-colors duration-150 ease-out-smooth hover:bg-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink disabled:opacity-40",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-sm font-medium",
											children: item.title
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-1 block text-sm text-muted",
											children: item.text
										})]
									}, item.title))
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "composer-pad mx-auto w-full max-w-3xl shrink-0 px-3 pt-2",
						children: [
							busyElsewhere ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => pendingId && useChatStore.getState().select(pendingId),
								className: "mb-2 text-sm text-muted underline-offset-2 hover:underline",
								children: "Ответ пишется в другом диалоге"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: (event) => {
									event.preventDefault();
									if (busyHere) return;
									sendText(draft);
								},
								className: "rounded-panel border border-line bg-canvas p-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "sr-only",
										htmlFor: "composer",
										children: "Сообщение"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										id: "composer",
										ref: composerRef,
										rows: 1,
										value: draft,
										placeholder: "Напишите сообщение",
										disabled: pendingId !== null,
										onChange: (event) => {
											setDraft(event.target.value);
											fitComposer(event.target);
										},
										onKeyDown: (event) => {
											if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing) {
												event.preventDefault();
												sendText(draft);
											}
										},
										className: "max-h-48 min-h-12 w-full resize-none bg-transparent px-2 py-2 text-base text-fg placeholder:text-faint focus:outline-none disabled:opacity-60"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-2 pr-1 pl-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-faint",
											children: tooLong ? "Сократите текст до 4000 знаков" : draft.trim().length > 3200 ? `${4e3 - draft.trim().length} знаков осталось` : "Grok 4.5"
										}), busyHere ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
											label: "Остановить",
											onClick: () => abortRef.current?.abort(),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-4 fill-current" })
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "submit",
											"aria-label": "Отправить",
											disabled: !draft.trim() || pendingId !== null || tooLong,
											className: "inline-flex size-11 items-center justify-center rounded-control bg-ink text-paper transition-opacity duration-150 hover:opacity-90 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink disabled:opacity-30",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-5" })
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "px-2 pt-2 pb-1 text-center text-xs text-faint",
								children: ["Ответы стоит перепроверять.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: " Enter — отправить, Shift+Enter — новая строка."
								})]
							})
						]
					})
				]
			})
		]
	});
}
function MessageRow({ message, isLast, pending, editing, onEditChange, onStartEdit, onCancelEdit, onSubmitEdit, onRegenerate }) {
	if (message.role === "user") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-end",
		children: [editing !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "w-full max-w-xl",
			onSubmit: (event) => {
				event.preventDefault();
				onSubmitEdit();
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				value: editing,
				"aria-label": "Изменить сообщение",
				onChange: (event) => onEditChange(event.target.value),
				className: "min-h-24 w-full rounded-panel border border-line bg-canvas p-3 text-base focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex justify-end gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onCancelEdit,
					className: "inline-flex min-h-11 items-center rounded-control px-3 text-sm hover:bg-hover",
					children: "Отмена"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "inline-flex min-h-11 items-center rounded-control bg-ink px-4 text-sm font-medium text-paper",
					children: "Отправить"
				})]
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "user-text w-fit max-w-xl rounded-panel bg-bubble px-4 py-3 text-bubble-fg",
			children: message.content
		}), editing === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { text: message.content }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
				label: "Изменить",
				disabled: pending,
				onClick: onStartEdit,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
			})]
		}) : null]
	});
	const showThinking = message.status === "streaming" && !message.content;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		showThinking ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "thinking text-sm font-medium",
			children: "Думаю"
		}) : message.content ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Markdown, {
			text: message.content,
			streaming: message.status === "streaming"
		}) : message.status === "stopped" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Остановлено"
		}) : null,
		message.status === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-danger",
			children: message.error || "Не получилось ответить."
		}) : null,
		message.status !== "streaming" && (message.content || message.status === "error") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-1 flex",
			children: [message.content ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { text: message.content }) : null, isLast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
				label: "Ответить заново",
				disabled: pending,
				onClick: onRegenerate,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4" })
			}) : null]
		}) : null
	] });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatApp, {});
}
//#endregion
export { Home as component };
