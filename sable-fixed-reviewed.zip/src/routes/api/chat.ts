import { createFileRoute } from "@tanstack/react-router";

type Turn = { role: "user" | "assistant"; content: string };

const MAX_BODY = 100_000;
const WINDOW_MS = 60_000;
const MAX_PER_WINDOW = 20;
const MAX_ACTIVE = 2;

// Актуальная доступная модель xAI (флагман на октябрь 2026)
const MODEL = "grok-4.7";

const hits: number[] = [];
let active = 0;

function takeSlot() {
  const now = Date.now();
  while (hits.length && (hits[0] ?? 0) < now - WINDOW_MS) hits.shift();
  if (hits.length >= MAX_PER_WINDOW || active >= MAX_ACTIVE) return false;
  hits.push(now);
  active += 1;
  return true;
}

function sanitize(body: unknown): Turn[] | null {
  if (!body || typeof body !== "object") return null;
  const messages = (body as { messages?: unknown }).messages;
  if (!Array.isArray(messages) || messages.length === 0 || messages.length > 16) return null;
  const turns: Turn[] = [];
  for (const item of messages) {
    if (!item || typeof item !== "object") return null;
    const role = (item as { role?: unknown }).role;
    const content = (item as { content?: unknown }).content;
    if ((role !== "user" && role !== "assistant") || typeof content !== "string") return null;
    const trimmed = content.trim();
    if (!trimmed || trimmed.length > 4000) return null;
    turns.push({ role, content: trimmed });
  }
  if (turns[turns.length - 1]?.role !== "user") return null;
  return turns;
}

function mapUpstreamError(status: number, detail: string): string {
  const lower = detail.toLowerCase();

  if (status === 401 || status === 403) {
    return "Неверный или просроченный API-ключ. Проверьте переменную XAI_API_KEY в настройках Vercel.";
  }
  // xAI may report exhausted credits/spending limits as HTTP 429 too,
  // so inspect the response body before treating every 429 as rate limiting.
  if (
    lower.includes("spending-limit") ||
    lower.includes("spending limit") ||
    lower.includes("insufficient balance") ||
    lower.includes("quota exceeded") ||
    lower.includes("billing")
  ) {
    return "Похоже, исчерпан доступный лимит или баланс API. Проверьте Usage и Billing в консоли xAI.";
  }
  if (status === 429) {
    return "Превышен лимит запросов. Подождите минуту и попробуйте снова.";
  }
  if (
    status === 404 ||
    (lower.includes("model") &&
      (lower.includes("not found") || lower.includes("does not exist")))
  ) {
    return `Модель ${MODEL} сейчас недоступна для этого API-ключа. Проверьте список доступных моделей в консоли xAI.`;
  }
  if (status >= 500) {
    return "Сервер модели временно недоступен. Попробуйте через несколько минут.";
  }
  return "Сейчас не получается ответить. Попробуйте ещё раз.";
}

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apiKey = process.env["XAI_API_KEY"]?.trim();
        if (!apiKey) {
          return Response.json(
            {
              error:
                "Не настроен API-ключ. Добавьте переменную окружения XAI_API_KEY в настройках проекта на Vercel (Settings → Environment Variables).",
            },
            { status: 503 },
          );
        }

        const raw = await request.text();
        if (raw.length > MAX_BODY) {
          return Response.json({ error: "Сообщение слишком длинное." }, { status: 413 });
        }

        let parsed: unknown;
        try {
          parsed = JSON.parse(raw);
        } catch {
          return Response.json({ error: "Не удалось прочитать запрос." }, { status: 400 });
        }

        const turns = sanitize(parsed);
        if (!turns) {
          return Response.json({ error: "Проверьте текст сообщения." }, { status: 400 });
        }

        if (!takeSlot()) {
          return Response.json(
            { error: "Слишком много запросов. Подождите минуту." },
            { status: 429 },
          );
        }

        let released = false;
        const release = () => {
          if (released) return;
          released = true;
          active = Math.max(0, active - 1);
        };

        const upstreamAbort = new AbortController();
        const onAbort = () => upstreamAbort.abort();
        request.signal.addEventListener("abort", onAbort);

        let upstream: Response;
        try {
          upstream = await fetch("https://api.x.ai/v1/chat/completions", {
            method: "POST",
            signal: upstreamAbort.signal,
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${apiKey}`,
            },
            body: JSON.stringify({
              model: MODEL,
              stream: true,
              max_tokens: 1400,
              temperature: 0.7,
              messages: [
                {
                  role: "system",
                  content:
                    "You are Sable, a direct conversational assistant. Reply in the same language the user writes in. Be concrete and accurate. Use markdown when it helps: short paragraphs, lists, and fenced code. If you are unsure, say so briefly.",
                },
                ...turns,
              ],
            }),
          });
        } catch {
          release();
          request.signal.removeEventListener("abort", onAbort);
          if (request.signal.aborted) return new Response(null, { status: 499 });
          return Response.json(
            { error: "Не удалось связаться с сервером модели. Проверьте интернет и попробуйте снова." },
            { status: 502 },
          );
        }

        if (!upstream.ok || !upstream.body) {
          let detail = "";
          try {
            detail = await upstream.text();
          } catch {
            detail = "";
          }
          release();
          request.signal.removeEventListener("abort", onAbort);
          const message = mapUpstreamError(upstream.status, detail);
          return Response.json({ error: message }, { status: 502 });
        }

        const encoder = new TextEncoder();
        const decoder = new TextDecoder();
        const reader = upstream.body.getReader();

        const stream = new ReadableStream({
          async start(controller) {
            const send = (payload: unknown) => {
              controller.enqueue(encoder.encode(`data: ${JSON.stringify(payload)}\n\n`));
            };
            let buffer = "";
            let got = false;
            try {
              while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                buffer += decoder.decode(value, { stream: true }).replace(/\r\n/g, "\n");
                const lines = buffer.split("\n");
                buffer = lines.pop() ?? "";
                for (const line of lines) {
                  const trimmed = line.trim();
                  if (!trimmed.startsWith("data:")) continue;
                  const data = trimmed.slice(5).trim();
                  if (!data || data === "[DONE]") continue;
                  try {
                    const json = JSON.parse(data) as {
                      choices?: { delta?: { content?: string } }[];
                    };
                    const delta = json.choices?.[0]?.delta?.content;
                    if (typeof delta === "string" && delta) {
                      got = true;
                      send({ delta });
                    }
                  } catch {
                    // Ignore a partial SSE frame.
                  }
                }
              }
              if (got) send({ done: true });
              else send({ error: "Пустой ответ. Попробуйте ещё раз." });
              controller.close();
            } catch {
              if (!request.signal.aborted) {
                try {
                  send({ error: "Соединение прервалось." });
                  controller.close();
                } catch {
                  // The client already left.
                }
              } else {
                try {
                  controller.close();
                } catch {
                  // Already closed.
                }
              }
            } finally {
              release();
              request.signal.removeEventListener("abort", onAbort);
              upstreamAbort.abort();
            }
          },
          cancel() {
            upstreamAbort.abort();
            release();
          },
        });

        return new Response(stream, {
          headers: {
            "Content-Type": "text/event-stream; charset=utf-8",
            "Cache-Control": "no-cache, no-transform",
            "X-Accel-Buffering": "no",
          },
        });
      },
    },
  },
});
