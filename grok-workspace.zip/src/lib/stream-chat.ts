import { apiUrl } from "@/lib/api-url";
import type { ChatTurn } from "@/lib/chat-store";

export async function streamReply(
  messages: ChatTurn[],
  signal: AbortSignal,
  onDelta: (delta: string) => void,
) {
  const response = await fetch(apiUrl("/api/chat"), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ messages }),
    signal,
  });

  if (!response.ok) {
    let message = "Сейчас не получается ответить. Попробуйте ещё раз.";
    try {
      const body = (await response.json()) as { error?: unknown };
      if (typeof body.error === "string" && body.error) message = body.error;
    } catch {
      // Keep the fallback copy.
    }
    throw new Error(message);
  }

  if (!response.body) {
    throw new Error("Сейчас не получается ответить. Попробуйте ещё раз.");
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  const handle = (raw: string) => {
    const data = raw
      .split("\n")
      .filter((line) => line.startsWith("data:"))
      .map((line) => line.slice(5).trim())
      .join("");
    if (!data) return;
    let payload: { delta?: string; error?: string };
    try {
      payload = JSON.parse(data) as { delta?: string; error?: string };
    } catch {
      throw new Error("Сейчас не получается ответить. Попробуйте ещё раз.");
    }
    if (payload.error) throw new Error(payload.error);
    if (payload.delta) onDelta(payload.delta);
  };

  const consume = (chunk: string, flush: boolean) => {
    buffer += chunk.replace(/\r\n/g, "\n");
    let splitAt = buffer.indexOf("\n\n");
    while (splitAt >= 0) {
      const raw = buffer.slice(0, splitAt);
      buffer = buffer.slice(splitAt + 2);
      handle(raw);
      splitAt = buffer.indexOf("\n\n");
    }
    if (flush && buffer.trim()) {
      handle(buffer);
      buffer = "";
    }
  };

  while (true) {
    const { done, value } = await reader.read();
    if (done) {
      consume(decoder.decode(), true);
      break;
    }
    consume(decoder.decode(value, { stream: true }), false);
  }
}
