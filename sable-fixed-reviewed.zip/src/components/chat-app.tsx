import { useEffect, useRef, useState, type ButtonHTMLAttributes } from "react";
import { isToday, isYesterday } from "date-fns";
import {
  ArrowUp,
  Check,
  Copy,
  Moon,
  PanelLeft,
  Pencil,
  Plus,
  RefreshCw,
  Search,
  Square,
  SquarePen,
  Sun,
  Trash2,
  X,
} from "lucide-react";
import { cn } from "@/lib/cn";
import {
  useChatStore,
  type ChatMessage,
  type Conversation,
} from "@/lib/chat-store";
import { Markdown } from "@/lib/markdown";
import { streamReply } from "@/lib/stream-chat";

const SUGGESTIONS = [
  {
    title: "Объяснить просто",
    text: "Квантовая запутанность без формул",
    prompt: "Объясни квантовую запутанность простыми словами, без формул.",
  },
  {
    title: "План на неделю",
    text: "TypeScript для тех, кто знает JavaScript",
    prompt:
      "Составь план на 7 дней, чтобы подтянуть TypeScript, если я уже пишу на JavaScript.",
  },
  {
    title: "Вежливое письмо",
    text: "Отказ от встречи без выдуманных причин",
    prompt: "Помоги вежливо отказаться от встречи, не выдумывая причин и без лишней воды.",
  },
  {
    title: "Ужин из обычного",
    text: "Пять идей из яиц, пасты и овощей",
    prompt:
      "Предложи 5 ужинов из продуктов, которые обычно есть дома: яйца, макароны, овощи, сыр.",
  },
] as const;

function groupLabel(ts: number) {
  if (isToday(ts)) return "Сегодня";
  if (isYesterday(ts)) return "Вчера";
  if (Date.now() - ts < 7 * 24 * 60 * 60 * 1000) return "На этой неделе";
  return "Ранее";
}

function IconButton({
  label,
  className,
  children,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { label: string }) {
  return (
    <button
      type="button"
      aria-label={label}
      className={cn(
        "inline-flex size-11 shrink-0 items-center justify-center rounded-control text-muted transition-colors duration-150 ease-out-smooth hover:bg-hover hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink disabled:pointer-events-none disabled:opacity-40",
        className,
      )}
      {...props}
    >
      {children}
    </button>
  );
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <IconButton
      label={copied ? "Скопировано" : "Копировать"}
      onClick={() => {
        void navigator.clipboard.writeText(text).then(
          () => {
            setCopied(true);
            window.setTimeout(() => setCopied(false), 1400);
          },
          () => undefined,
        );
      }}
    >
      {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
    </IconButton>
  );
}

export function ChatApp() {
  const conversations = useChatStore((state) => state.conversations);
  const activeId = useChatStore((state) => state.activeId);
  const theme = useChatStore((state) => state.theme);
  const active = conversations.find((item) => item.id === activeId) ?? null;

  const [draft, setDraft] = useState("");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [pendingId, setPendingId] = useState<string | null>(null);
  const [editing, setEditing] = useState<{ id: string; text: string } | null>(null);
  const [rename, setRename] = useState<{ id: string; text: string } | null>(null);
  const [confirmId, setConfirmId] = useState<string | null>(null);

  const abortRef = useRef<AbortController | null>(null);
  const inflight = useRef(false);
  const scrollerRef = useRef<HTMLDivElement>(null);
  const stickRef = useRef(true);
  const composerRef = useRef<HTMLTextAreaElement>(null);
  const skipRenameBlur = useRef(false);

  useEffect(() => {
    void useChatStore.persist.rehydrate();
  }, []);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  useEffect(() => {
    setEditing(null);
    stickRef.current = true;
  }, [activeId]);

  const tail = active?.messages[active.messages.length - 1];
  useEffect(() => {
    const el = scrollerRef.current;
    if (!el || !stickRef.current) return;
    el.scrollTop = el.scrollHeight;
  }, [active?.id, active?.messages.length, tail?.content, tail?.status]);

  useEffect(() => {
    if (!sidebarOpen) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setSidebarOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [sidebarOpen]);

  const fitComposer = (node: HTMLTextAreaElement | null) => {
    if (!node) return;
    node.style.height = "0px";
    node.style.height = `${Math.min(node.scrollHeight, 192)}px`;
  };

  const run = async (
    convId: string,
    assistantId: string,
    history: { role: "user" | "assistant"; content: string }[],
  ) => {
    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    setPendingId(convId);
    try {
      await streamReply(history, ctrl.signal, (delta) => {
        useChatStore.getState().appendDelta(convId, assistantId, delta);
      });
      useChatStore.getState().finish(convId, assistantId, "done");
    } catch (error) {
      if (ctrl.signal.aborted) {
        useChatStore.getState().finish(convId, assistantId, "stopped");
        return;
      }
      const message =
        error instanceof Error && error.message
          ? error.message
          : "Сейчас не получается ответить. Попробуйте ещё раз.";
      useChatStore.getState().finish(convId, assistantId, "error", message);
    } finally {
      if (abortRef.current === ctrl) abortRef.current = null;
      inflight.current = false;
      setPendingId((current) => (current === convId ? null : current));
    }
  };

  const sendText = (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || inflight.current || trimmed.length > 4000) return;
    inflight.current = true;
    const { convId, assistantId, history } = useChatStore
      .getState()
      .commitUser(useChatStore.getState().activeId, trimmed);
    setDraft("");
    if (composerRef.current) composerRef.current.style.height = "0px";
    setSidebarOpen(false);
    void run(convId, assistantId, history);
  };

  const startNew = () => {
    useChatStore.getState().select(null);
    setDraft("");
    setSidebarOpen(false);
    composerRef.current?.focus();
  };

  const busyHere = pendingId !== null && pendingId === active?.id;
  const busyElsewhere = pendingId !== null && pendingId !== active?.id;
  const tooLong = draft.trim().length > 4000;

  const filtered = conversations
    .slice()
    .sort((a, b) => b.updatedAt - a.updatedAt)
    .filter((item) => {
      const q = query.trim().toLowerCase();
      if (!q) return true;
      return (
        item.title.toLowerCase().includes(q) ||
        item.messages.some((message) => message.content.toLowerCase().includes(q))
      );
    });

  const groups: { label: string; items: Conversation[] }[] = [];
  for (const item of filtered) {
    const label = groupLabel(item.updatedAt);
    const last = groups[groups.length - 1];
    if (!last || last.label !== label) groups.push({ label, items: [item] });
    else last.items.push(item);
  }

  return (
    <div className="flex h-dvh overflow-hidden bg-paper text-fg">
      {sidebarOpen ? (
        <button
          type="button"
          aria-label="Закрыть список диалогов"
          className="fixed inset-0 z-30 bg-ink/40 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      ) : null}

      <aside
        className={cn(
          "sidebar-panel fixed inset-y-0 left-0 z-40 flex w-72 shrink-0 flex-col bg-sidebar text-sidebar-fg md:static",
          sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0",
        )}
      >
        <div className="px-4 pt-5 pb-3">
          <div className="font-serif text-2xl leading-none tracking-tight">Sable</div>
          <p className="mt-2 text-xs text-sidebar-muted">На модели Grok</p>
        </div>
        <div className="px-3">
          <button
            type="button"
            onClick={startNew}
            className="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-control bg-sidebar-fg px-3 text-sm font-medium text-sidebar transition-opacity duration-150 hover:opacity-90 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sidebar-fg"
          >
            <Plus className="size-4" />
            Новый диалог
          </button>
        </div>
        <div className="px-3 pt-3">
          <div className="relative">
            <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-sidebar-muted" />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Поиск по диалогам"
              aria-label="Поиск по диалогам"
              className="h-11 w-full rounded-control border border-sidebar-line bg-transparent pr-3 pl-10 text-sm text-sidebar-fg placeholder:text-sidebar-muted focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sidebar-fg"
            />
          </div>
        </div>
        <div className="mt-3 min-h-0 flex-1 overflow-y-auto px-2 pb-3">
          {groups.length === 0 ? (
            <p className="px-3 py-6 text-sm text-sidebar-muted">
              {query.trim() ? "Ничего не нашлось" : "Диалогов пока нет"}
            </p>
          ) : (
            groups.map((group) => (
              <section key={group.label} className="mb-3">
                <h2 className="px-3 py-2 text-xs font-medium text-sidebar-muted">{group.label}</h2>
                <ul>
                  {group.items.map((item) => {
                    const selected = item.id === activeId;
                    return (
                      <li key={item.id} className="chat-row flex items-center rounded-control">
                        {rename?.id === item.id ? (
                          <input
                            autoFocus
                            value={rename.text}
                            aria-label="Название диалога"
                            onChange={(event) =>
                              setRename({ id: item.id, text: event.target.value })
                            }
                            onBlur={() => {
                              if (skipRenameBlur.current) {
                                skipRenameBlur.current = false;
                                return;
                              }
                              useChatStore.getState().rename(item.id, rename.text);
                              setRename(null);
                            }}
                            onKeyDown={(event) => {
                              if (event.key === "Enter") event.currentTarget.blur();
                              if (event.key === "Escape") {
                                skipRenameBlur.current = true;
                                setRename(null);
                              }
                            }}
                            className="mx-1 h-11 min-w-0 flex-1 rounded-control border border-sidebar-line bg-sidebar px-2 text-sm text-sidebar-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sidebar-fg"
                          />
                        ) : (
                          <button
                            type="button"
                            aria-current={selected ? "page" : undefined}
                            onClick={() => {
                              useChatStore.getState().select(item.id);
                              setSidebarOpen(false);
                              setConfirmId(null);
                            }}
                            className={cn(
                              "min-h-11 min-w-0 flex-1 truncate rounded-control px-3 text-left text-sm",
                              selected ? "bg-sidebar-hover" : "hover:bg-sidebar-hover",
                            )}
                          >
                            {item.title}
                          </button>
                        )}
                        <div className="row-actions flex shrink-0">
                          {confirmId === item.id ? (
                            <>
                              <button
                                type="button"
                                className="inline-flex h-11 items-center px-2 text-xs font-medium text-danger"
                                onClick={() => {
                                  useChatStore.getState().remove(item.id);
                                  setConfirmId(null);
                                }}
                              >
                                Удалить
                              </button>
                              <IconButton
                                label="Отмена"
                                className="text-sidebar-muted hover:bg-sidebar-hover hover:text-sidebar-fg"
                                onClick={() => setConfirmId(null)}
                              >
                                <X className="size-4" />
                              </IconButton>
                            </>
                          ) : (
                            <>
                              <IconButton
                                label="Переименовать"
                                className="text-sidebar-muted hover:bg-sidebar-hover hover:text-sidebar-fg"
                                onClick={() => setRename({ id: item.id, text: item.title })}
                              >
                                <Pencil className="size-4" />
                              </IconButton>
                              <IconButton
                                label="Удалить диалог"
                                className="text-sidebar-muted hover:bg-sidebar-hover hover:text-sidebar-fg"
                                onClick={() => setConfirmId(item.id)}
                              >
                                <Trash2 className="size-4" />
                              </IconButton>
                            </>
                          )}
                        </div>
                      </li>
                    );
                  })}
                </ul>
              </section>
            ))
          )}
        </div>
        <div className="flex items-center justify-between border-t border-sidebar-line px-2 py-2">
          <button
            type="button"
            onClick={() =>
              useChatStore.getState().setTheme(theme === "dark" ? "light" : "dark")
            }
            className="inline-flex min-h-11 items-center gap-2 rounded-control px-3 text-sm text-sidebar-fg hover:bg-sidebar-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sidebar-fg"
          >
            {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
            {theme === "dark" ? "Светлая" : "Тёмная"}
          </button>
          <span className="pr-3 text-xs text-sidebar-muted">Grok 4.7</span>
        </div>
      </aside>

      <main className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-14 shrink-0 items-center gap-1 px-2">
          <IconButton
            label="Открыть список диалогов"
            className="md:hidden"
            onClick={() => setSidebarOpen(true)}
          >
            <PanelLeft className="size-5" />
          </IconButton>
          <h1 className="min-w-0 flex-1 truncate px-2 text-center text-sm font-medium">
            {active?.title ?? "Sable"}
          </h1>
          <IconButton label="Новый диалог" className="md:hidden" onClick={startNew}>
            <SquarePen className="size-5" />
          </IconButton>
        </header>

        <div
          ref={scrollerRef}
          onScroll={(event) => {
            const el = event.currentTarget;
            stickRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
          }}
          className="min-h-0 flex-1 overflow-y-auto"
        >
          {active && active.messages.length > 0 ? (
            <div className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-4 py-4">
              {active.messages.map((message, index) => (
                <MessageRow
                  key={message.id}
                  message={message}
                  isLast={index === active.messages.length - 1}
                  pending={busyHere}
                  editing={editing?.id === message.id ? editing.text : null}
                  onEditChange={(text) => setEditing({ id: message.id, text })}
                  onStartEdit={() => setEditing({ id: message.id, text: message.content })}
                  onCancelEdit={() => setEditing(null)}
                  onSubmitEdit={() => {
                    if (!editing || inflight.current) return;
                    const text = editing.text.trim();
                    if (!text || text.length > 4000) return;
                    inflight.current = true;
                    const result = useChatStore
                      .getState()
                      .rewindUser(active.id, message.id, text);
                    setEditing(null);
                    if (!result) {
                      inflight.current = false;
                      return;
                    }
                    void run(active.id, result.assistantId, result.history);
                  }}
                  onRegenerate={() => {
                    if (inflight.current) return;
                    inflight.current = true;
                    const result = useChatStore.getState().regenerate(active.id);
                    if (!result) {
                      inflight.current = false;
                      return;
                    }
                    void run(active.id, result.assistantId, result.history);
                  }}
                />
              ))}
            </div>
          ) : (
            <div className="mx-auto flex min-h-full w-full max-w-2xl flex-col justify-center px-4 py-8">
              <h2 className="display-title text-center">С чего начнём?</h2>
              <p className="mx-auto mt-3 max-w-md text-center text-sm text-muted">
                Спросите, попросите черновик или разберите задачу. Диалоги остаются в этом
                браузере.
              </p>
              <div className="mt-8 grid grid-cols-1 gap-2 sm:grid-cols-2">
                {SUGGESTIONS.map((item) => (
                  <button
                    key={item.title}
                    type="button"
                    disabled={pendingId !== null}
                    onClick={() => sendText(item.prompt)}
                    className="min-h-11 rounded-panel border border-line bg-canvas px-4 py-3 text-left transition-colors duration-150 ease-out-smooth hover:bg-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink disabled:opacity-40"
                  >
                    <span className="block text-sm font-medium">{item.title}</span>
                    <span className="mt-1 block text-sm text-muted">{item.text}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="composer-pad mx-auto w-full max-w-3xl shrink-0 px-3 pt-2">
          {busyElsewhere ? (
            <button
              type="button"
              onClick={() => pendingId && useChatStore.getState().select(pendingId)}
              className="mb-2 text-sm text-muted underline-offset-2 hover:underline"
            >
              Ответ пишется в другом диалоге
            </button>
          ) : null}
          <form
            onSubmit={(event) => {
              event.preventDefault();
              if (busyHere) return;
              sendText(draft);
            }}
            className="rounded-panel border border-line bg-canvas p-2"
          >
            <label className="sr-only" htmlFor="composer">
              Сообщение
            </label>
            <textarea
              id="composer"
              ref={composerRef}
              rows={1}
              value={draft}
              placeholder="Напишите сообщение"
              disabled={pendingId !== null}
              onChange={(event) => {
                setDraft(event.target.value);
                fitComposer(event.target);
              }}
              onKeyDown={(event) => {
                if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing) {
                  event.preventDefault();
                  sendText(draft);
                }
              }}
              className="max-h-48 min-h-12 w-full resize-none bg-transparent px-2 py-2 text-base text-fg placeholder:text-faint focus:outline-none disabled:opacity-60"
            />
            <div className="flex items-center justify-between gap-2 pr-1 pl-2">
              <p className="text-xs text-faint">
                {tooLong
                  ? "Сократите текст до 4000 знаков"
                  : draft.trim().length > 3200
                    ? `${4000 - draft.trim().length} знаков осталось`
                    : "Grok 4.7"}
              </p>
              {busyHere ? (
                <IconButton label="Остановить" onClick={() => abortRef.current?.abort()}>
                  <Square className="size-4 fill-current" />
                </IconButton>
              ) : (
                <button
                  type="submit"
                  aria-label="Отправить"
                  disabled={!draft.trim() || pendingId !== null || tooLong}
                  className="inline-flex size-11 items-center justify-center rounded-control bg-ink text-paper transition-opacity duration-150 hover:opacity-90 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink disabled:opacity-30"
                >
                  <ArrowUp className="size-5" />
                </button>
              )}
            </div>
          </form>
          <p className="px-2 pt-2 pb-1 text-center text-xs text-faint">
            Ответы стоит перепроверять.
            <span className="hidden sm:inline"> Enter — отправить, Shift+Enter — новая строка.</span>
          </p>
        </div>
      </main>
    </div>
  );
}

function MessageRow({
  message,
  isLast,
  pending,
  editing,
  onEditChange,
  onStartEdit,
  onCancelEdit,
  onSubmitEdit,
  onRegenerate,
}: {
  message: ChatMessage;
  isLast: boolean;
  pending: boolean;
  editing: string | null;
  onEditChange: (text: string) => void;
  onStartEdit: () => void;
  onCancelEdit: () => void;
  onSubmitEdit: () => void;
  onRegenerate: () => void;
}) {
  if (message.role === "user") {
    return (
      <div className="flex flex-col items-end">
        {editing !== null ? (
          <form
            className="w-full max-w-xl"
            onSubmit={(event) => {
              event.preventDefault();
              onSubmitEdit();
            }}
          >
            <textarea
              value={editing}
              aria-label="Изменить сообщение"
              onChange={(event) => onEditChange(event.target.value)}
              className="min-h-24 w-full rounded-panel border border-line bg-canvas p-3 text-base focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink"
            />
            <div className="mt-2 flex justify-end gap-2">
              <button
                type="button"
                onClick={onCancelEdit}
                className="inline-flex min-h-11 items-center rounded-control px-3 text-sm hover:bg-hover"
              >
                Отмена
              </button>
              <button
                type="submit"
                className="inline-flex min-h-11 items-center rounded-control bg-ink px-4 text-sm font-medium text-paper"
              >
                Отправить
              </button>
            </div>
          </form>
        ) : (
          <div className="user-text w-fit max-w-xl rounded-panel bg-bubble px-4 py-3 text-bubble-fg">
            {message.content}
          </div>
        )}
        {editing === null ? (
          <div className="flex">
            <CopyButton text={message.content} />
            <IconButton label="Изменить" disabled={pending} onClick={onStartEdit}>
              <Pencil className="size-4" />
            </IconButton>
          </div>
        ) : null}
      </div>
    );
  }

  const showThinking = message.status === "streaming" && !message.content;
  return (
    <div>
      {showThinking ? (
        <p className="thinking text-sm font-medium">Думаю</p>
      ) : message.content ? (
        <Markdown text={message.content} streaming={message.status === "streaming"} />
      ) : message.status === "stopped" ? (
        <p className="text-sm text-muted">Остановлено</p>
      ) : null}
      {message.status === "error" ? (
        <p className="mt-2 text-sm text-danger">{message.error || "Не получилось ответить."}</p>
      ) : null}
      {message.status !== "streaming" && (message.content || message.status === "error") ? (
        <div className="mt-1 flex">
          {message.content ? <CopyButton text={message.content} /> : null}
          {isLast ? (
            <IconButton label="Ответить заново" disabled={pending} onClick={onRegenerate}>
              <RefreshCw className="size-4" />
            </IconButton>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
