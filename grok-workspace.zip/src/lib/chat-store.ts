import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Role = "user" | "assistant";
export type MessageStatus = "done" | "streaming" | "error" | "stopped";

export type ChatMessage = {
  id: string;
  role: Role;
  content: string;
  createdAt: number;
  status: MessageStatus;
  error?: string;
};

export type Conversation = {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatMessage[];
};

export type ChatTurn = { role: Role; content: string };

type ChatState = {
  conversations: Conversation[];
  activeId: string | null;
  theme: "light" | "dark";
  setTheme: (theme: "light" | "dark") => void;
  select: (id: string | null) => void;
  remove: (id: string) => void;
  rename: (id: string, title: string) => void;
  commitUser: (activeId: string | null, text: string) => {
    convId: string;
    assistantId: string;
    history: ChatTurn[];
  };
  rewindUser: (
    convId: string,
    messageId: string,
    text: string,
  ) => { assistantId: string; history: ChatTurn[] } | null;
  regenerate: (convId: string) => { assistantId: string; history: ChatTurn[] } | null;
  appendDelta: (convId: string, messageId: string, delta: string) => void;
  finish: (convId: string, messageId: string, status: MessageStatus, error?: string) => void;
};

const MAX_CONVERSATIONS = 40;
const TITLE_FALLBACK = "Новый диалог";

function uid() {
  return crypto.randomUUID();
}

export function titleFrom(text: string) {
  const line = text.trim().split("\n")[0]?.replace(/\s+/g, " ") ?? "";
  if (!line) return TITLE_FALLBACK;
  return line.length > 42 ? `${line.slice(0, 42).trimEnd()}…` : line;
}

function historyFrom(messages: ChatMessage[]): ChatTurn[] {
  return messages
    .filter((message) => message.content.trim() && message.role)
    .filter((message) => message.role === "user" || message.status === "done")
    .slice(-12)
    .map((message) => ({
      role: message.role,
      content: message.content.trim().slice(0, 4000),
    }));
}

function touch(conversations: Conversation[]) {
  return [...conversations]
    .sort((a, b) => b.updatedAt - a.updatedAt)
    .slice(0, MAX_CONVERSATIONS);
}

export const useChatStore = create<ChatState>()(
  persist(
    (set, get) => ({
      conversations: [],
      activeId: null,
      theme: "light",
      setTheme: (theme) => set({ theme }),
      select: (id) => set({ activeId: id }),
      remove: (id) =>
        set((state) => {
          const conversations = state.conversations.filter((item) => item.id !== id);
          const nextActive = conversations
            .slice()
            .sort((a, b) => b.updatedAt - a.updatedAt)[0]?.id;
          return {
            conversations,
            activeId: state.activeId === id ? (nextActive ?? null) : state.activeId,
          };
        }),
      rename: (id, title) =>
        set((state) => ({
          conversations: state.conversations.map((item) =>
            item.id === id
              ? { ...item, title: title.trim() || TITLE_FALLBACK, updatedAt: Date.now() }
              : item,
          ),
        })),
      commitUser: (activeId, text) => {
        const now = Date.now();
        const user: ChatMessage = {
          id: uid(),
          role: "user",
          content: text.trim(),
          createdAt: now,
          status: "done",
        };
        const assistant: ChatMessage = {
          id: uid(),
          role: "assistant",
          content: "",
          createdAt: now,
          status: "streaming",
        };
        const existing = get().conversations.find((item) => item.id === activeId);
        if (!existing) {
          const conv: Conversation = {
            id: uid(),
            title: titleFrom(text),
            createdAt: now,
            updatedAt: now,
            messages: [user, assistant],
          };
          set((state) => ({
            activeId: conv.id,
            conversations: touch([conv, ...state.conversations]),
          }));
          return { convId: conv.id, assistantId: assistant.id, history: historyFrom([user]) };
        }
        const messages = [...existing.messages, user, assistant];
        const title =
          existing.messages.some((message) => message.role === "user") ||
          existing.title !== TITLE_FALLBACK
            ? existing.title
            : titleFrom(text);
        const next: Conversation = { ...existing, title, messages, updatedAt: now };
        set((state) => ({
          activeId: existing.id,
          conversations: touch(
            state.conversations.map((item) => (item.id === existing.id ? next : item)),
          ),
        }));
        return {
          convId: existing.id,
          assistantId: assistant.id,
          history: historyFrom(messages.slice(0, -1)),
        };
      },
      rewindUser: (convId, messageId, text) => {
        const conv = get().conversations.find((item) => item.id === convId);
        if (!conv) return null;
        const index = conv.messages.findIndex((message) => message.id === messageId);
        if (index < 0 || conv.messages[index]?.role !== "user") return null;
        const now = Date.now();
        const user: ChatMessage = {
          ...conv.messages[index]!,
          content: text.trim(),
          status: "done",
        };
        const assistant: ChatMessage = {
          id: uid(),
          role: "assistant",
          content: "",
          createdAt: now,
          status: "streaming",
        };
        const messages = [...conv.messages.slice(0, index), user, assistant];
        set((state) => ({
          conversations: state.conversations.map((item) =>
            item.id === convId
              ? {
                  ...item,
                  title: index === 0 ? titleFrom(text) : item.title,
                  messages,
                  updatedAt: now,
                }
              : item,
          ),
        }));
        return { assistantId: assistant.id, history: historyFrom(messages.slice(0, -1)) };
      },
      regenerate: (convId) => {
        const conv = get().conversations.find((item) => item.id === convId);
        if (!conv) return null;
        const last = conv.messages[conv.messages.length - 1];
        if (!last || last.role !== "assistant") return null;
        const now = Date.now();
        const assistant: ChatMessage = {
          ...last,
          content: "",
          error: undefined,
          status: "streaming",
          createdAt: now,
        };
        const messages = [...conv.messages.slice(0, -1), assistant];
        set((state) => ({
          conversations: state.conversations.map((item) =>
            item.id === convId ? { ...item, messages, updatedAt: now } : item,
          ),
        }));
        return { assistantId: assistant.id, history: historyFrom(messages.slice(0, -1)) };
      },
      appendDelta: (convId, messageId, delta) =>
        set((state) => ({
          conversations: state.conversations.map((item) =>
            item.id !== convId
              ? item
              : {
                  ...item,
                  messages: item.messages.map((message) =>
                    message.id === messageId && message.status === "streaming"
                      ? { ...message, content: message.content + delta }
                      : message,
                  ),
                },
          ),
        })),
      finish: (convId, messageId, status, error) =>
        set((state) => ({
          conversations: state.conversations.map((item) =>
            item.id !== convId
              ? item
              : {
                  ...item,
                  updatedAt: Date.now(),
                  messages: item.messages.map((message) =>
                    message.id === messageId ? { ...message, status, error } : message,
                  ),
                },
          ),
        })),
    }),
    {
      name: "sable-chat-v1",
      skipHydration: true,
      partialize: (state) => ({
        conversations: state.conversations,
        activeId: state.activeId,
        theme: state.theme,
      }),
      onRehydrateStorage: () => (state) => {
        if (!state) return;
        useChatStore.setState({
          conversations: state.conversations.map((conversation) => ({
            ...conversation,
            messages: conversation.messages.map((message) =>
              message.status === "streaming" ? { ...message, status: "stopped" } : message,
            ),
          })),
        });
      },
    },
  ),
);
