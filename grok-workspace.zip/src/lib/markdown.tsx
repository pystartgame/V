import { useState } from "react";
import { Check, Copy } from "lucide-react";

type Inline =
  | { type: "text"; text: string }
  | { type: "code"; text: string }
  | { type: "strong"; text: string }
  | { type: "em"; text: string }
  | { type: "link"; text: string; href: string };

type Block =
  | { type: "p"; inlines: Inline[] }
  | { type: "h"; level: 1 | 2 | 3; inlines: Inline[] }
  | { type: "code"; lang: string; code: string }
  | { type: "ul"; items: Inline[][] }
  | { type: "ol"; items: Inline[][] }
  | { type: "quote"; inlines: Inline[] }
  | { type: "hr" };

function parseInlines(src: string): Inline[] {
  const out: Inline[] = [];
  let buf = "";
  let i = 0;
  const flush = () => {
    if (!buf) return;
    out.push({ type: "text", text: buf });
    buf = "";
  };

  while (i < src.length) {
    if (src[i] === "`") {
      const end = src.indexOf("`", i + 1);
      if (end > i + 1) {
        flush();
        out.push({ type: "code", text: src.slice(i + 1, end) });
        i = end + 1;
        continue;
      }
    }
    if (src.startsWith("**", i) || src.startsWith("__", i)) {
      const mark = src.slice(i, i + 2);
      const end = src.indexOf(mark, i + 2);
      if (end > i + 2) {
        flush();
        out.push({ type: "strong", text: src.slice(i + 2, end) });
        i = end + 2;
        continue;
      }
    }
    if ((src[i] === "*" || src[i] === "_") && src[i + 1] !== src[i]) {
      const mark = src[i]!;
      const end = src.indexOf(mark, i + 1);
      if (end > i + 1) {
        flush();
        out.push({ type: "em", text: src.slice(i + 1, end) });
        i = end + 1;
        continue;
      }
    }
    if (src[i] === "[") {
      const close = src.indexOf("]", i + 1);
      if (close > i + 1 && src[close + 1] === "(") {
        const end = src.indexOf(")", close + 2);
        if (end > close + 2) {
          const href = src.slice(close + 2, end).trim();
          if (/^https?:\/\//i.test(href)) {
            flush();
            out.push({ type: "link", text: src.slice(i + 1, close), href });
            i = end + 1;
            continue;
          }
        }
      }
    }
    buf += src[i];
    i += 1;
  }
  flush();
  return out;
}

function isFence(line: string) {
  return line.trimStart().startsWith("```");
}

function parseBlocks(src: string): Block[] {
  const lines = src.replace(/\r\n/g, "\n").split("\n");
  const blocks: Block[] = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i] ?? "";

    if (isFence(line)) {
      const lang = line.trim().slice(3).trim();
      const code: string[] = [];
      i += 1;
      while (i < lines.length && !isFence(lines[i] ?? "")) {
        code.push(lines[i] ?? "");
        i += 1;
      }
      if (i < lines.length) i += 1;
      blocks.push({ type: "code", lang, code: code.join("\n") });
      continue;
    }

    const heading = /^(#{1,3})\s+(.+)$/.exec(line);
    if (heading) {
      blocks.push({
        type: "h",
        level: heading[1]!.length as 1 | 2 | 3,
        inlines: parseInlines(heading[2]!),
      });
      i += 1;
      continue;
    }

    if (/^(-{3,}|\*{3,})$/.test(line.trim())) {
      blocks.push({ type: "hr" });
      i += 1;
      continue;
    }

    if (/^\s*>\s?/.test(line)) {
      const parts: string[] = [];
      while (i < lines.length && /^\s*>\s?/.test(lines[i] ?? "")) {
        parts.push((lines[i] ?? "").replace(/^\s*>\s?/, ""));
        i += 1;
      }
      blocks.push({ type: "quote", inlines: parseInlines(parts.join(" ")) });
      continue;
    }

    if (/^\s*[-*]\s+/.test(line)) {
      const items: Inline[][] = [];
      while (i < lines.length && /^\s*[-*]\s+/.test(lines[i] ?? "")) {
        items.push(parseInlines((lines[i] ?? "").replace(/^\s*[-*]\s+/, "")));
        i += 1;
      }
      blocks.push({ type: "ul", items });
      continue;
    }

    if (/^\s*\d+\.\s+/.test(line)) {
      const items: Inline[][] = [];
      while (i < lines.length && /^\s*\d+\.\s+/.test(lines[i] ?? "")) {
        items.push(parseInlines((lines[i] ?? "").replace(/^\s*\d+\.\s+/, "")));
        i += 1;
      }
      blocks.push({ type: "ol", items });
      continue;
    }

    if (line.trim() === "") {
      i += 1;
      continue;
    }

    const para: string[] = [];
    while (i < lines.length) {
      const current = lines[i] ?? "";
      if (
        current.trim() === "" ||
        isFence(current) ||
        /^(#{1,3})\s+/.test(current) ||
        /^(-{3,}|\*{3,})$/.test(current.trim()) ||
        /^\s*>\s?/.test(current) ||
        /^\s*[-*]\s+/.test(current) ||
        /^\s*\d+\.\s+/.test(current)
      ) {
        break;
      }
      para.push(current.trim());
      i += 1;
    }
    if (para.length) {
      blocks.push({ type: "p", inlines: parseInlines(para.join(" ")) });
    }
  }

  return blocks;
}

function Inlines({ items }: { items: Inline[] }) {
  return (
    <>
      {items.map((item, index) => {
        if (item.type === "text") return <span key={index}>{item.text}</span>;
        if (item.type === "code") return <code key={index}>{item.text}</code>;
        if (item.type === "strong") return <strong key={index}>{item.text}</strong>;
        if (item.type === "em") return <em key={index}>{item.text}</em>;
        return (
          <a key={index} href={item.href} target="_blank" rel="noreferrer noopener">
            {item.text}
          </a>
        );
      })}
    </>
  );
}

function CodeBlock({ lang, code }: { lang: string; code: string }) {
  const [copied, setCopied] = useState(false);

  return (
    <div className="code-block">
      <header>
        <span>{lang || "код"}</span>
        <button
          type="button"
          className="inline-flex min-h-10 items-center gap-1 rounded-control px-2 text-xs text-muted hover:bg-hover hover:text-fg"
          onClick={() => {
            void navigator.clipboard.writeText(code).then(() => {
              setCopied(true);
              window.setTimeout(() => setCopied(false), 1400);
            });
          }}
        >
          {copied ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
          {copied ? "Скопировано" : "Копировать"}
        </button>
      </header>
      <pre>
        <code>{code}</code>
      </pre>
    </div>
  );
}

export function Markdown({ text, streaming = false }: { text: string; streaming?: boolean }) {
  const blocks = parseBlocks(text);
  if (!blocks.length) return streaming ? <span className="stream-caret" aria-hidden /> : null;
  return (
    <div className="prose-chat">
      {blocks.map((block, index) => {
        const caret =
          streaming && index === blocks.length - 1 ? (
            <span className="stream-caret" aria-hidden />
          ) : null;
        if (block.type === "p") {
          return (
            <p key={index}>
              <Inlines items={block.inlines} />
              {caret}
            </p>
          );
        }
        if (block.type === "h") {
          const Tag = `h${block.level}` as "h1" | "h2" | "h3";
          return (
            <Tag key={index}>
              <Inlines items={block.inlines} />
              {caret}
            </Tag>
          );
        }
        if (block.type === "code") {
          return (
            <div key={index}>
              <CodeBlock lang={block.lang} code={block.code} />
              {caret}
            </div>
          );
        }
        if (block.type === "ul" || block.type === "ol") {
          const Tag = block.type === "ul" ? "ul" : "ol";
          return (
            <div key={index}>
              <Tag>
                {block.items.map((item, itemIndex) => (
                  <li key={itemIndex}>
                    <Inlines items={item} />
                  </li>
                ))}
              </Tag>
              {caret}
            </div>
          );
        }
        if (block.type === "quote") {
          return (
            <blockquote key={index}>
              <Inlines items={block.inlines} />
              {caret}
            </blockquote>
          );
        }
        return <hr key={index} />;
      })}
    </div>
  );
}
